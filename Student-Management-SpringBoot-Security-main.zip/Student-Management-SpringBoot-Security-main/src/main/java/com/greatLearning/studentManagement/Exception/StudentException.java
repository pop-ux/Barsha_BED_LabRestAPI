package com.greatLearning.studentManagement.Exception;

public class StudentException extends Exception{
    public StudentException(String message) {
        super(message);
    }
}
